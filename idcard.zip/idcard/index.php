<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php
error_reporting(0);
if(isset($_POST['submit'])){
	$value=$_POST['value'];
}


?>

<form action="" method="POST">

<input type="text" name="value" />
<input type="submit" value="submit" name="submit" />




</form>

<?php

for($i=0; $i<=$value;$i++){





?>




    <div class="container"  >
        <div class="content">
            <h5>FUTURE COMPUTER TRAING INSTITUTE</h5>
            <div class="row">
            <div class="logo">
                <img src="main-logo.png" alt="">


            </div>
            <h5>Institute code : 44047</h5>

            <div class="logo">

<img src="bteb-logo.png" alt="">

            </div>


            </div>

<div class="img">
    
    <img src="gojo.png" alt="">
</div>



<div class="h1">
    <h3>Sataro Jogo</h3>
</div>
<h2>Roll : 440646</h2>
<h2>Blood Group : O+</h2>
<h2>Batch : FCTI-B37</h2>
<h3>Contact : 8801902323788</h3>
<h4>Computer Office Application</h4>
<div class="end"><h5>futurecomputer.net</h5></div>







        </div>
    </div>
<?php } ?>
</body>
</html>